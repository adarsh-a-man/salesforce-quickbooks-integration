# Salesforce -> Quickbooks Integration

This repository is a sample integration that pushes Salesforce accounts and a custom Salesforce invoice to a customer in QuickBooks and an invoice in QuickBooks. This code is production ready and is derived from a live use case.

# Youtube Video

Please see the Youtube video below to follow through the source code and see a demo:
https://youtu.be/4lHYeHZRe3k